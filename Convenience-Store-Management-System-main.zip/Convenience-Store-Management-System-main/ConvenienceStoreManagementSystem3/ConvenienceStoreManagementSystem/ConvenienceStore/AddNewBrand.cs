﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConvenienceStore
{
    public partial class AddNewBrand : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnect dbcon = new DBConnect();

        // Định nghĩa sự kiện để thông báo khi dữ liệu được lưu thành công
        public event EventHandler BrandAdded;
        public AddNewBrand()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.myConnection());
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Dispose(); 
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Xác nhận lưu thông tin?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    // Kiểm tra giá trị đầu vào
                    string maThuongHieu = txtBrandCode.Text.Trim();
                    string tenThuongHieu = txtBrandName.Text.Trim();

                    if (string.IsNullOrWhiteSpace(maThuongHieu) || string.IsNullOrWhiteSpace(tenThuongHieu))
                    {
                        MessageBox.Show("Vui lòng nhập đầy đủ mã thương hiệu và tên thương hiệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    // Kiểm tra độ dài của MaThuongHieu (tối đa 10 ký tự vì kiểu dữ liệu là nvarchar(10))
                    if (maThuongHieu.Length > 10)
                    {
                        MessageBox.Show("Mã thương hiệu không được dài quá 10 ký tự!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Kiểm tra độ dài của TenThuongHieu (tối đa 50 ký tự vì kiểu dữ liệu là nvarchar(50))
                    if (tenThuongHieu.Length > 50)
                    {
                        MessageBox.Show("Tên thương hiệu không được dài quá 50 ký tự!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                    {
                        cn.Open();

                        // Kiểm tra xem MaThuongHieu đã tồn tại hay chưa
                        using (SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM THUONGHIEU WHERE MaThuongHieu = @MaThuongHieu", cn))
                        {
                            checkCmd.Parameters.AddWithValue("@MaThuongHieu", maThuongHieu);
                            int count = (int)checkCmd.ExecuteScalar();
                            if (count > 0)
                            {
                                MessageBox.Show("Mã thương hiệu đã tồn tại! Vui lòng chọn mã khác.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }

                        // Chèn dữ liệu vào bảng THUONGHIEU
                        using (SqlCommand cm = new SqlCommand("INSERT INTO THUONGHIEU (MaThuongHieu, TenThuongHieu) VALUES (@MaThuongHieu, @TenThuongHieu)", cn))
                        {
                            cm.Parameters.AddWithValue("@MaThuongHieu", maThuongHieu);
                            cm.Parameters.AddWithValue("@TenThuongHieu", tenThuongHieu);
                            int rowsAffected = cm.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Lưu thông tin thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                // Xóa trắng các TextBox để chuẩn bị cho lần nhập tiếp theo
                                txtBrandCode.Clear();
                                txtBrandName.Clear();

                                // Kích hoạt sự kiện BrandSaved để thông báo cho form cha
                                BrandAdded?.Invoke(this, EventArgs.Empty);
                            }
                            else
                            {
                                MessageBox.Show("Không có dữ liệu nào được lưu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtBrandCode.Clear() ;
            txtBrandName.Clear() ;
            txtBrandCode.Focus();
        }
    }
}
