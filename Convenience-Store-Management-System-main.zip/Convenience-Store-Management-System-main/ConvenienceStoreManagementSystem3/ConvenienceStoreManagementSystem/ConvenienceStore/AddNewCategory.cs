﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConvenienceStore
{
    public partial class AddNewCategory : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnect dbcon = new DBConnect();

        // Định nghĩa sự kiện để thông báo khi dữ liệu được lưu thành công
        public event EventHandler CategoryAdded;
        public AddNewCategory()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.myConnection());
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Xác nhận lưu thông tin danh mục?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    // Kiểm tra giá trị đầu vào
                    string tenDanhMuc = txtCategoryName.Text.Trim();

                    if (string.IsNullOrWhiteSpace(tenDanhMuc))
                    {
                        MessageBox.Show("Vui lòng nhập tên danh mục!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Kiểm tra độ dài của TenDanhMuc (giả sử tối đa 50 ký tự, bạn có thể điều chỉnh theo cấu trúc bảng)
                    if (tenDanhMuc.Length > 50)
                    {
                        MessageBox.Show("Tên danh mục không được dài quá 50 ký tự!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                    {
                        cn.Open();

                        // Kiểm tra xem TenDanhMuc đã tồn tại hay chưa
                        using (SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM DANHMUC WHERE TenDanhMuc = @TenDanhMuc", cn))
                        {
                            checkCmd.Parameters.AddWithValue("@TenDanhMuc", tenDanhMuc);
                            int count = (int)checkCmd.ExecuteScalar();
                            if (count > 0)
                            {
                                MessageBox.Show("Tên danh mục đã tồn tại! Vui lòng chọn tên khác.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }

                        // Chèn dữ liệu vào bảng DANHMUC
                        // Giả sử MaDanhMuc là kiểu tự tăng (IDENTITY), nên không cần nhập
                        using (SqlCommand cm = new SqlCommand("INSERT INTO DANHMUC (TenDanhMuc) VALUES (@TenDanhMuc)", cn))
                        {
                            cm.Parameters.AddWithValue("@TenDanhMuc", tenDanhMuc);
                            int rowsAffected = cm.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Lưu thông tin danh mục thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                // Xóa trắng TextBox để chuẩn bị cho lần nhập tiếp theo
                                txtCategoryName.Clear();

                                // Kích hoạt sự kiện CategoryAdded để thông báo cho form cha
                                CategoryAdded?.Invoke(this, EventArgs.Empty);
                            }
                            else
                            {
                                MessageBox.Show("Không có dữ liệu nào được lưu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtCategoryName.Clear();
            txtCategoryName.Focus();
        }
    }
}
