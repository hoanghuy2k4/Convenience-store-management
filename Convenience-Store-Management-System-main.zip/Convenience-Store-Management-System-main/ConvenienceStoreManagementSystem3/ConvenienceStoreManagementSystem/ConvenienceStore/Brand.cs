﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConvenienceStore
{
    public partial class Brand : Form  
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnect dbcon = new DBConnect();

        private List<BrandData> allBrands = new List<BrandData>(); // Lưu toàn bộ thương hiệu
        private int pageSize = 23; // Số dòng mỗi trang
        private int currentPage = 1; // Trang hiện tại
        private int totalPages; // Tổng số trang

        // Class để lưu thông tin thương hiệu
        public class BrandData
        {
            public int STT { get; set; }
            public string MaThuongHieu { get; set; }
            public string TenThuongHieu { get; set; }
        }
        public Brand()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.myConnection());

            dgvBrand.Height = (20 * 40) + dgvBrand.ColumnHeadersHeight;

            LoadBrand();
        }

        public void LoadBrand()
        {
            try
            {
                // Xóa dữ liệu cũ
                allBrands.Clear();
                int i = 0; // Biến đếm cho STT

                // Tải dữ liệu từ cơ sở dữ liệu
                using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                {
                    cn.Open();
                    using (SqlCommand cm = new SqlCommand("SELECT MaThuongHieu, TenThuongHieu FROM THUONGHIEU ORDER BY TenThuongHieu", cn))
                    {
                        using (SqlDataReader dr = cm.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                i++; // Tăng STT
                                allBrands.Add(new BrandData
                                {
                                    STT = i,
                                    MaThuongHieu = dr["MaThuongHieu"].ToString(),
                                    TenThuongHieu = dr["TenThuongHieu"].ToString()
                                });
                            }
                        }
                    }
                }

                // Tính tổng số trang
                totalPages = (int)Math.Ceiling((double)allBrands.Count / pageSize);

                // Hiển thị trang đầu tiên
                currentPage = 1; // Đặt lại về trang 1
                LoadPage(currentPage);

                // Hiển thị thông báo nếu không có dữ liệu
                if (allBrands.Count == 0)
                {
                    MessageBox.Show("Không có thương hiệu nào trong danh sách.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi khi tải danh sách thương hiệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void picAddBrand_Click(object sender, EventArgs e)
        {
            try
            {
                AddNewBrand moduleForm1 = new AddNewBrand();

                // Đăng ký lắng nghe sự kiện BrandSaved
                moduleForm1.BrandAdded += (s, args) =>
                {
                    LoadBrand(); // Làm mới DataGridView khi dữ liệu được lưu
                };

                moduleForm1.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi khi mở form thêm thương hiệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };
        }

        private void dgvBrand_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string colName = dgvBrand.Columns[e.ColumnIndex].Name;
                if (colName == "Delete")
                {
                    if (MessageBox.Show("Bạn có chắc chắn muốn xóa thương hiệu này không?", "Xóa Thương Hiệu", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                        {
                            cn.Open();
                            using (SqlCommand cm = new SqlCommand("DELETE FROM THUONGHIEU WHERE MaThuongHieu = @MaThuongHieu", cn))
                            {
                                cm.Parameters.AddWithValue("@MaThuongHieu", dgvBrand.Rows[e.RowIndex].Cells["MaThuongHieu"].Value.ToString());
                                cm.ExecuteNonQuery();
                            }
                        }
                        MessageBox.Show("Thương hiệu đã được xóa thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadBrand(); // Làm mới danh sách sau khi xóa
                    }
                }
                else if (colName == "Edit")
                {
                    string maCu = dgvBrand[1, e.RowIndex].Value.ToString();  // Lấy mã thương hiệu cũ
                    string tenThuongHieu = dgvBrand[2, e.RowIndex].Value.ToString(); // Lấy tên thương hiệu

                    UpdateBrand updateForm = new UpdateBrand(maCu, tenThuongHieu);
                    updateForm.BrandSaved += (s, args) =>
                    {
                        LoadBrand(); // Load lại danh sách sau khi cập nhật
                    };

                    updateForm.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadPage(int page)
        {
            // Xóa dữ liệu cũ trong DataGridView
            dgvBrand.Rows.Clear();

            // Tính chỉ số bắt đầu và kết thúc của trang
            int startIndex = (page - 1) * pageSize;
            int endIndex = Math.Min(startIndex + pageSize, allBrands.Count);

            // Thêm các dòng vào DataGridView
            for (int i = startIndex; i < endIndex; i++)
            {
                var brand = allBrands[i];
                dgvBrand.Rows.Add(brand.STT, brand.MaThuongHieu, brand.TenThuongHieu);
            }

            // Cập nhật thông tin trang
            lblPageInfo.Text = $"Trang {currentPage}/{totalPages}";

            // Cập nhật trạng thái các nút điều hướng
            btnFirst.Enabled = (currentPage > 1); // Vô hiệu hóa nếu đang ở trang đầu
            btnPrevious.Enabled = (currentPage > 1);
            btnNext.Enabled = (currentPage < totalPages);
            btnLast.Enabled = (currentPage < totalPages); // Vô hiệu hóa nếu đang ở trang cuối
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            currentPage = 1; // Chuyển về trang đầu tiên
            LoadPage(currentPage);
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (currentPage > 1)
            {
                currentPage--;
                LoadPage(currentPage);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (currentPage < totalPages)
            {
                currentPage++;
                LoadPage(currentPage);
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            currentPage = totalPages; // Chuyển đến trang cuối cùng
            LoadPage(currentPage);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
           

    

