﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConvenienceStore
{
    public partial class Category : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnect dbcon = new DBConnect();

        private List<CategoryData> allCategories = new List<CategoryData>(); // Lưu toàn bộ danh mục
        private int pageSize = 23; // Số dòng mỗi trang
        private int currentPage = 1; // Trang hiện tại
        private int totalPages; // Tổng số trang

        // Class để lưu thông tin danh mục
        public class CategoryData
        {
            public int STT { get; set; }
            public string MaDanhMuc { get; set; }
            public string TenDanhMuc { get; set; }
        }
        public Category()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.myConnection());

            // Thiết lập DataGridView
            dgvCategory.Height = (20 * 40) + dgvCategory.ColumnHeadersHeight;

            LoadCategory();
        }

        public void LoadCategory()
        {
            try
            {
                // Xóa dữ liệu cũ
                allCategories.Clear();

                // Tải dữ liệu từ cơ sở dữ liệu
                using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                {
                    cn.Open();
                    using (SqlCommand cm = new SqlCommand("SELECT MaDanhMuc, TenDanhMuc FROM DANHMUC ORDER BY TenDanhMuc", cn))
                    {
                        using (SqlDataReader dr = cm.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                allCategories.Add(new CategoryData
                                {
                                    STT = Convert.ToInt32(dr["MaDanhMuc"]), // Sử dụng MaDanhMuc làm STT
                                    MaDanhMuc = dr["MaDanhMuc"].ToString(), // Lưu MaDanhMuc để sử dụng sau
                                    TenDanhMuc = dr["TenDanhMuc"].ToString()
                                });
                            }
                        }
                    }
                }

                // Tính tổng số trang
                totalPages = (int)Math.Ceiling((double)allCategories.Count / pageSize);

                // Hiển thị trang đầu tiên
                currentPage = 1; // Đặt lại về trang 1
                LoadPage(currentPage);

                // Hiển thị thông báo nếu không có dữ liệu
                if (allCategories.Count == 0)
                {
                    MessageBox.Show("Không có danh mục nào trong danh sách.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi khi tải danh sách danh mục: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void picAddCategory_Click(object sender, EventArgs e)
        {
            try
            {
                AddNewCategory moduleForm = new AddNewCategory();

                // Đăng ký lắng nghe sự kiện CategoryAdded
                moduleForm.CategoryAdded += (s, args) =>
                {
                    LoadCategory(); // Làm mới DataGridView khi dữ liệu được lưu
                };

                moduleForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi khi mở form thêm danh mục: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvCategory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string colName = dgvCategory.Columns[e.ColumnIndex].Name;
                if (colName == "Delete")
                {
                    if (MessageBox.Show("Bạn có chắc chắn muốn xóa danh mục này không?", "Xóa Danh Mục", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        // Lấy MaDanhMuc từ danh sách allCategories
                        string maDanhMuc = allCategories[(currentPage - 1) * pageSize + e.RowIndex].MaDanhMuc;

                        using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                        {
                            cn.Open();
                            using (SqlCommand cm = new SqlCommand("DELETE FROM DANHMUC WHERE MaDanhMuc = @MaDanhMuc", cn))
                            {
                                cm.Parameters.AddWithValue("@MaDanhMuc", maDanhMuc);
                                cm.ExecuteNonQuery();
                            }
                        }
                        MessageBox.Show("Danh mục đã được xóa thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadCategory(); // Làm mới danh sách sau khi xóa
                    }
                }
                else if (colName == "Edit")
                {
                    // Lấy MaDanhMuc và TenDanhMuc từ danh sách allCategories
                    string maDanhMuc = allCategories[(currentPage - 1) * pageSize + e.RowIndex].MaDanhMuc;
                    string tenDanhMuc = allCategories[(currentPage - 1) * pageSize + e.RowIndex].TenDanhMuc;

                    UpdateCategory updateForm = new UpdateCategory(maDanhMuc, tenDanhMuc);
                    updateForm.CategorySaved += (s, args) =>
                    {
                        LoadCategory(); // Load lại danh sách sau khi cập nhật
                    };

                    updateForm.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadPage(int page)
        {
            // Xóa dữ liệu cũ trong DataGridView
            dgvCategory.Rows.Clear();

            // Tính chỉ số bắt đầu và kết thúc của trang
            int startIndex = (page - 1) * pageSize;
            int endIndex = Math.Min(startIndex + pageSize, allCategories.Count);

            // Thêm các dòng vào DataGridView (chỉ hiển thị STT và TenDanhMuc)
            for (int i = startIndex; i < endIndex; i++)
            {
                var category = allCategories[i];
                dgvCategory.Rows.Add(category.STT, category.TenDanhMuc);
            }

            // Cập nhật thông tin trang
            lblPageInfo.Text = $"Trang {currentPage}/{totalPages}";

            // Cập nhật trạng thái các nút điều hướng
            btnFirst.Enabled = (currentPage > 1); // Vô hiệu hóa nếu đang ở trang đầu
            btnPrevious.Enabled = (currentPage > 1);
            btnNext.Enabled = (currentPage < totalPages);
            btnLast.Enabled = (currentPage < totalPages); // Vô hiệu hóa nếu đang ở trang cuối
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (currentPage < totalPages)
            {
                currentPage++;
                LoadPage(currentPage);
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            currentPage = totalPages; // Chuyển đến trang cuối cùng
            LoadPage(currentPage);
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (currentPage > 1)
            {
                currentPage--;
                LoadPage(currentPage);
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            currentPage = 1; // Chuyển về trang đầu tiên
            LoadPage(currentPage);
        }
    }
}

