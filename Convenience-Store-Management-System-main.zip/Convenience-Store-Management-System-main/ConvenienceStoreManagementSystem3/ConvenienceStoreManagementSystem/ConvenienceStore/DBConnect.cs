﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConvenienceStore
{
     class DBConnect
    {
        private string con;
        public string myConnection()
        {
            con = @"Data Source=.;Initial Catalog=QLCuaHangTienLoi;Integrated Security=True";
            return con;
        }
    }
}
