﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ConvenienceStore
{
    public partial class frmMain : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnect dbcon = new DBConnect();
        public frmMain()
        {
            InitializeComponent();
            customizeDesign();
            cn = new SqlConnection(dbcon.myConnection());
            cn.Open();
            MessageBox.Show("Kết nối cơ sở dữ liệu thành công!");
        }
        #region pnlSlide
        private void customizeDesign()
        {
            pnlSubProduct.Visible = false;
            pnlSubRecord.Visible = false;
            pnlSubSetting.Visible = false;
            pnlSubStock.Visible = false;
        }

        private void hideSubmenu()
        {
            if(pnlSubProduct.Visible == true)
                pnlSubProduct.Visible = false;
            if (pnlSubStock.Visible == true)
                pnlSubStock.Visible = false;
            if (pnlSubRecord.Visible == true)
                pnlSubRecord.Visible = false;
            if (pnlSubSetting.Visible == true)
                pnlSubSetting.Visible = false;
        }

        private void showSubmenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hideSubmenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;
        }
        #endregion pnlSlide

        private Form activeForm = null;
        public void openChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            lblTitle.Text = childForm.Text;
            pnlMain.Controls.Add(childForm);
            pnlMain.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void btnHomepage_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void btnProduct_Click(object sender, EventArgs e)
        {
            showSubmenu(pnlSubProduct);
        }

        private void btnProductList_Click(object sender, EventArgs e)
        {
            openChildForm(new Product());
        }

        private void btnCategory_Click(object sender, EventArgs e)
        {
            openChildForm(new Category());
        }

        private void btnBrand_Click(object sender, EventArgs e)
        {
            openChildForm(new Brand());

        }

        private void btnStock_Click(object sender, EventArgs e)
        {
            showSubmenu(pnlSubStock);
        }

        private void btnStockEntry_Click(object sender, EventArgs e)
        {
            
        }

        private void btnStockAdjustment_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void btnRecord_Click(object sender, EventArgs e)
        {
            showSubmenu(pnlSubRecord);
        }

        private void btnSaleHistory_Click(object sender, EventArgs e)
        {
           
        }

        private void btnDetailRecord_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            showSubmenu(pnlSubSetting);
        }

        private void btnUser_Click(object sender, EventArgs e)
        {
           
        }

        private void btnStore_Click(object sender, EventArgs e)
        {
            
        }

        private void btnBackup_Click(object sender, EventArgs e)
        {
           
        }

        private void btnRestore_Click(object sender, EventArgs e)
        {
            
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }
    }
}
