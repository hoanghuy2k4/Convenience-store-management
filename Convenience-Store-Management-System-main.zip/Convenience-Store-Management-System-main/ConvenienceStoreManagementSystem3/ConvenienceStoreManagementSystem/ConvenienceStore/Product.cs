﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConvenienceStore
{
    public partial class Product : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnect dbcon = new DBConnect();


        private List<ProductData> allProducts = new List<ProductData>();
        private List<ProductData> filteredProducts = new List<ProductData>();
        private int pageSize = 20;
        private int currentPage = 1;
        private int totalPages;


        // Class để lưu thông tin sản phẩm
        public class ProductData
        {
            public int STT { get; set; }
            public string MaSanPham { get; set; }
            public string TenSanPham { get; set; }
            public string TenThuongHieu { get; set; }
            public string TenDanhMuc { get; set; }
            public decimal GiaBan { get; set; }
            public int SoLuong { get; set; }
            public string TrangThai { get; set; }
            public string MaVach { get; set; }
            public string MaThuongHieu { get; set; }
            public int? MaDanhMuc { get; set; }
            public int? MaDonViTinh { get; set; }
            public int MucTaiDatHang { get; set; }
            public decimal GiaVon { get; set; }
            public string MaQuocGia { get; set; }
            public bool TrangThaiHoatDong { get; set; }
        }
        public Product()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.myConnection());

            // Thiết lập chiều cao cho DataGridView (20 dòng + tiêu đề)
            dgvProduct.Height = (20 * 40) + dgvProduct.ColumnHeadersHeight;
            // Gỡ bỏ sự kiện cũ (nếu có)
            cmbSearch.SelectedIndexChanged -= cmbSearch_SelectedIndexChanged;
            //cmbSearch.TextChanged -= cmbSearch_TextChanged;
            cmbFilterBrand.SelectedIndexChanged -= cmbFilterBrand_SelectedIndexChanged;
            cmbFilterCategory.SelectedIndexChanged -= cmbFilterCategory_SelectedIndexChanged;
            cmbFilterStatus.SelectedIndexChanged -= cmbFilterStatus_SelectedIndexChanged;

            LoadProduct();
            LoadFilters();

            // Đăng ký lại sự kiện
            cmbSearch.SelectedIndexChanged += cmbSearch_SelectedIndexChanged;
            //cmbSearch.TextChanged += cmbSearch_TextChanged;
            cmbFilterBrand.SelectedIndexChanged += cmbFilterBrand_SelectedIndexChanged;
            cmbFilterCategory.SelectedIndexChanged += cmbFilterCategory_SelectedIndexChanged;
            cmbFilterStatus.SelectedIndexChanged += cmbFilterStatus_SelectedIndexChanged;
        }

        private void frmProduct_Load(object sender, EventArgs e)
        {

            if (allProducts.Count == 0)
            {
                LoadProduct();
            }
        }

        private void LoadFilters()
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                {
                    cn.Open();

                    DataTable brandTable = new DataTable();
                    using (SqlDataAdapter da = new SqlDataAdapter("SELECT MaThuongHieu, TenThuongHieu FROM THUONGHIEU", cn))
                    {
                        da.Fill(brandTable);
                    }
                    DataRow allBrandsRow = brandTable.NewRow();
                    allBrandsRow["MaThuongHieu"] = DBNull.Value;
                    allBrandsRow["TenThuongHieu"] = "Tất cả thương hiệu";
                    brandTable.Rows.InsertAt(allBrandsRow, 0);
                    cmbFilterBrand.DataSource = null;
                    cmbFilterBrand.DataSource = brandTable;
                    cmbFilterBrand.DisplayMember = "TenThuongHieu";
                    cmbFilterBrand.ValueMember = "MaThuongHieu";
                    cmbFilterBrand.SelectedIndex = 0;

                    DataTable categoryTable = new DataTable();
                    using (SqlDataAdapter da = new SqlDataAdapter("SELECT MaDanhMuc, TenDanhMuc FROM DANHMUC", cn))
                    {
                        da.Fill(categoryTable);
                    }
                    DataRow allCategoriesRow = categoryTable.NewRow();
                    allCategoriesRow["MaDanhMuc"] = DBNull.Value;
                    allCategoriesRow["TenDanhMuc"] = "Tất cả danh mục";
                    categoryTable.Rows.InsertAt(allCategoriesRow, 0);
                    cmbFilterCategory.DataSource = null;
                    cmbFilterCategory.DataSource = categoryTable;
                    cmbFilterCategory.DisplayMember = "TenDanhMuc";
                    cmbFilterCategory.ValueMember = "MaDanhMuc";
                    cmbFilterCategory.SelectedIndex = 0;

                    if (cmbFilterStatus.Items.Count == 0)
                    {
                        cmbFilterStatus.Items.AddRange(new string[] { "Tất cả trạng thái", "Còn Hàng", "Sắp Hết Hàng", "Hết Hàng", "Ngừng Hoạt Động" });
                    }
                    cmbFilterStatus.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi khi tải bộ lọc: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LoadProduct()
        {
            try
            {
                allProducts.Clear();
                int i = 0;

                using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                {
                    cn.Open();
                    using (SqlCommand cm = new SqlCommand(
                        "SELECT sp.MaSanPham, sp.MaVach, sp.TenSanPham, sp.GiaBan, sp.SoLuong, sp.MucTaiDatHang, sp.MaThuongHieu, sp.MaDanhMuc, sp.MaDonViTinh, sp.TrangThaiHoatDong, sp.MaQuocGia, sp.GiaVon, dm.TenDanhMuc, th.TenThuongHieu " +
                        "FROM SANPHAM sp " +
                        "LEFT JOIN DANHMUC dm ON sp.MaDanhMuc = dm.MaDanhMuc " +
                        "LEFT JOIN THUONGHIEU th ON sp.MaThuongHieu = th.MaThuongHieu " +
                        "ORDER BY sp.TenSanPham", cn))
                    {
                        using (SqlDataReader dr = cm.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                i++;

                                int soLuong = 0;
                                if (!dr.IsDBNull(dr.GetOrdinal("SoLuong")))
                                {
                                    if (!int.TryParse(dr["SoLuong"].ToString(), out soLuong))
                                    {
                                        throw new FormatException($"Giá trị không hợp lệ trong cột SoLuong của sản phẩm {dr["MaSanPham"].ToString()}: {dr["SoLuong"].ToString()}");
                                    }
                                }

                                int mucTaiDatHang = 0;
                                if (!dr.IsDBNull(dr.GetOrdinal("MucTaiDatHang")))
                                {
                                    if (!int.TryParse(dr["MucTaiDatHang"].ToString(), out mucTaiDatHang))
                                    {
                                        throw new FormatException($"Giá trị không hợp lệ trong cột MucTaiDatHang của sản phẩm {dr["MaSanPham"].ToString()}: {dr["MucTaiDatHang"].ToString()}");
                                    }
                                }

                                bool trangThaiHoatDong = false;
                                if (!dr.IsDBNull(dr.GetOrdinal("TrangThaiHoatDong")))
                                {
                                    if (!bool.TryParse(dr["TrangThaiHoatDong"].ToString(), out trangThaiHoatDong))
                                    {
                                        throw new FormatException($"Giá trị không hợp lệ trong cột TrangThaiHoatDong của sản phẩm {dr["MaSanPham"].ToString()}: {dr["TrangThaiHoatDong"].ToString()}");
                                    }
                                }

                                decimal giaBan = 0;
                                if (!dr.IsDBNull(dr.GetOrdinal("GiaBan")))
                                {
                                    if (!decimal.TryParse(dr["GiaBan"].ToString(), out giaBan))
                                    {
                                        throw new FormatException($"Giá trị không hợp lệ trong cột GiaBan của sản phẩm {dr["MaSanPham"].ToString()}: {dr["GiaBan"].ToString()}");
                                    }
                                }

                                decimal giaVon = 0;
                                if (!dr.IsDBNull(dr.GetOrdinal("GiaVon")))
                                {
                                    if (!decimal.TryParse(dr["GiaVon"].ToString(), out giaVon))
                                    {
                                        throw new FormatException($"Giá trị không hợp lệ trong cột GiaVon của sản phẩm {dr["MaSanPham"].ToString()}: {dr["GiaVon"].ToString()}");
                                    }
                                }

                                string trangThai;
                                if (trangThaiHoatDong)
                                {
                                    if (soLuong > mucTaiDatHang)
                                        trangThai = "Còn Hàng";
                                    else if (soLuong == 0)
                                        trangThai = "Hết Hàng";
                                    else
                                        trangThai = "Sắp Hết Hàng";
                                }
                                else
                                {
                                    trangThai = "Ngừng Hoạt Động";
                                }

                                allProducts.Add(new ProductData
                                {
                                    STT = i,
                                    MaSanPham = dr["MaSanPham"].ToString(),
                                    TenSanPham = dr["TenSanPham"].ToString(),
                                    TenThuongHieu = dr["TenThuongHieu"]?.ToString() ?? "Không có",
                                    TenDanhMuc = dr["TenDanhMuc"]?.ToString() ?? "Không có",
                                    GiaBan = giaBan,
                                    SoLuong = soLuong,
                                    TrangThai = trangThai,
                                    MaVach = dr["MaVach"].ToString(),
                                    MaThuongHieu = dr.IsDBNull(dr.GetOrdinal("MaThuongHieu")) ? null : dr["MaThuongHieu"].ToString(),
                                    MaDanhMuc = dr.IsDBNull(dr.GetOrdinal("MaDanhMuc")) ? (int?)null : Convert.ToInt32(dr["MaDanhMuc"]),
                                    MaDonViTinh = dr.IsDBNull(dr.GetOrdinal("MaDonViTinh")) ? (int?)null : Convert.ToInt32(dr["MaDonViTinh"]),
                                    MucTaiDatHang = mucTaiDatHang,
                                    GiaVon = giaVon,
                                    MaQuocGia = dr["MaQuocGia"]?.ToString(),
                                    TrangThaiHoatDong = trangThaiHoatDong
                                });
                            }
                        }
                    }
                }

                // Tải danh sách gợi ý vào cmbSearch
                cmbSearch.Items.Clear();
                var productNames = allProducts.Select(p => p.TenSanPham).Distinct().OrderBy(name => name).ToList();
                foreach (var name in productNames)
                {
                    cmbSearch.Items.Add(name);
                }
                cmbSearch.SelectedIndex = -1; // Không chọn mục nào mặc định

                filteredProducts = new List<ProductData>(allProducts);

                totalPages = (int)Math.Ceiling((double)filteredProducts.Count / pageSize);
                if (totalPages == 0) totalPages = 1;

                currentPage = 1;
                LoadPage(currentPage);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi khi tải danh sách sản phẩm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadPage(int page)
        {
            dgvProduct.Rows.Clear();

            int startIndex = (page - 1) * pageSize;
            int endIndex = Math.Min(startIndex + pageSize, filteredProducts.Count);

            for (int i = startIndex; i < endIndex; i++)
            {
                var product = filteredProducts[i];
                string formattedPrice = product.GiaBan.ToString("N0") + " VNĐ";
                DataGridViewRow row = new DataGridViewRow();
                row.CreateCells(dgvProduct, product.STT, product.MaSanPham, product.TenSanPham, product.TenDanhMuc, formattedPrice, product.SoLuong, product.TrangThai);

                DataGridViewCell statusCell = row.Cells[6];
                if (product.TrangThaiHoatDong)
                {
                    if (product.TrangThai == "Còn Hàng")
                    {
                        statusCell.Style.BackColor = Color.Green;
                        statusCell.Style.ForeColor = Color.White;
                    }
                    else if (product.TrangThai == "Sắp Hết Hàng")
                    {
                        statusCell.Style.BackColor = Color.Yellow;
                        statusCell.Style.ForeColor = Color.Black;
                    }
                    else if (product.TrangThai == "Hết Hàng")
                    {
                        statusCell.Style.BackColor = Color.Red;
                        statusCell.Style.ForeColor = Color.White;
                    }
                }
                else
                {
                    statusCell.Style.BackColor = Color.Gray;
                    statusCell.Style.ForeColor = Color.White;
                }

                dgvProduct.Rows.Add(row);
            }

            lblPageInfo.Text = $"Trang {currentPage}/{totalPages}";

            btnFirst.Enabled = (currentPage > 1);
            btnPrevious.Enabled = (currentPage > 1);
            btnNext.Enabled = (currentPage < totalPages);
            btnLast.Enabled = (currentPage < totalPages);
        }


        private void ApplyFilters()
        {
            string searchText = cmbSearch.SelectedItem?.ToString()?.Trim().ToLower() ?? "";
            string filterBrand = cmbFilterBrand.SelectedValue != null && cmbFilterBrand.SelectedValue != DBNull.Value ? cmbFilterBrand.SelectedValue.ToString() : null;
            string filterCategory = cmbFilterCategory.SelectedValue != null && cmbFilterCategory.SelectedValue != DBNull.Value ? cmbFilterCategory.SelectedValue.ToString() : null;
            string filterStatus = null;

            switch (cmbFilterStatus.SelectedIndex)
            {
                case 0:
                    filterStatus = "";
                    break;
                case 1:
                    filterStatus = "Còn Hàng";
                    break;
                case 2:
                    filterStatus = "Sắp Hết Hàng";
                    break;
                case 3:
                    filterStatus = "Hết Hàng";
                    break;
                case 4:
                    filterStatus = "Ngừng Hoạt Động";
                    break;
            }

            filteredProducts.Clear();

            foreach (var product in allProducts)
            {
                bool matchesSearch = string.IsNullOrEmpty(searchText) ||
                    product.TenSanPham.ToLower() == searchText;

                bool matchesBrand = string.IsNullOrEmpty(filterBrand) ||
                    (product.MaThuongHieu != null && product.MaThuongHieu == filterBrand);

                bool matchesCategory = string.IsNullOrEmpty(filterCategory) ||
                    (product.MaDanhMuc.HasValue && product.MaDanhMuc.ToString() == filterCategory);

                bool matchesStatus = string.IsNullOrEmpty(filterStatus) ||
                    product.TrangThai == filterStatus;

                if (matchesSearch && matchesBrand && matchesCategory && matchesStatus)
                {
                    filteredProducts.Add(product);
                }
            }

            for (int i = 0; i < filteredProducts.Count; i++)
            {
                filteredProducts[i].STT = i + 1;
            }

            totalPages = (int)Math.Ceiling((double)filteredProducts.Count / pageSize);
            if (totalPages == 0) totalPages = 1;
            currentPage = 1;
            LoadPage(currentPage);
        }

        private void picAddProduct_Click(object sender, EventArgs e)
        {
            try
            {
                ProductModule addForm = new ProductModule();

                // Đăng ký lắng nghe sự kiện ProductAdded
                addForm.ProductAdded += (s, args) =>
                {
                    LoadProduct(); // Làm mới DataGridView khi dữ liệu được lưu
                };

                addForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi khi mở form thêm sản phẩm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string colName = dgvProduct.Columns[e.ColumnIndex].Name;
                if (colName == "View")
                {
                    var product = filteredProducts[e.RowIndex + (currentPage - 1) * pageSize];
                    ProductDetails detailsForm = new ProductDetails(product);
                    detailsForm.ProductUpdated += (s, args) =>
                    {
                        LoadProduct(); // Làm mới danh sách sản phẩm
                    };
                    detailsForm.ShowDialog();
                }
                else if (colName == "Edit")
                {
                    var product = filteredProducts[e.RowIndex + (currentPage - 1) * pageSize];
                    ProductModule editForm = new ProductModule(product);
                    editForm.ProductAdded += (s, args) =>
                    {
                        LoadProduct();
                    };
                    editForm.ShowDialog();
                }
                else if (colName == "Delete")
                {
                    if (MessageBox.Show("Bạn có chắc chắn muốn xóa sản phẩm này không?", "Xóa Sản Phẩm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                        {
                            cn.Open();
                            using (SqlCommand cm = new SqlCommand("DELETE FROM SANPHAM WHERE MaSanPham = @MaSanPham", cn))
                            {
                                cm.Parameters.AddWithValue("@MaSanPham", dgvProduct.Rows[e.RowIndex].Cells["MaSanPham"].Value.ToString());
                                cm.ExecuteNonQuery();
                            }
                        }
                        MessageBox.Show("Sản phẩm đã được xóa thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadProduct();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            currentPage = 1;
            LoadPage(currentPage);
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (currentPage > 1)
            {
                currentPage--;
                LoadPage(currentPage);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (currentPage < totalPages)
            {
                currentPage++;
                LoadPage(currentPage);
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            currentPage = totalPages;
            LoadPage(currentPage);
        }


        private void cmbFilterBrand_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyFilters();
        }

        private void cmbFilterCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyFilters();
        }

        private void cmbFilterStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyFilters();
        }

        private void cmbSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyFilters();
        }

        private void picClearFilters_Click(object sender, EventArgs e)
        {
            // Đặt lại các bộ lọc về trạng thái mặc định
            cmbSearch.Text = "";
            cmbSearch.SelectedIndex = -1;
            cmbFilterBrand.SelectedIndex = 0; // "Tất cả thương hiệu"
            cmbFilterCategory.SelectedIndex = 0; // "Tất cả danh mục"
            cmbFilterStatus.SelectedIndex = 0; // "Tất cả trạng thái"

            // Tải lại danh sách sản phẩm đầy đủ
            filteredProducts = new List<ProductData>(allProducts);
            totalPages = (int)Math.Ceiling((double)filteredProducts.Count / pageSize);
            if (totalPages == 0) totalPages = 1;
            currentPage = 1;
            LoadPage(currentPage);
        }
    }

}