﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ConvenienceStore.Product;

namespace ConvenienceStore
{
    public partial class ProductDetails : Form
    {
        private Product.ProductData product;
        public event EventHandler ProductUpdated;

        private DBConnect dbcon = new DBConnect();
        public ProductDetails(Product.ProductData productData)
        {
            InitializeComponent();
            this.product = productData;

            LoadProductDetails();
        }

        private void LoadProductDetails()
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                {
                    cn.Open();

                    // Lấy tên thương hiệu
                    string tenThuongHieu = "Không có dữ liệu!";
                    if (!string.IsNullOrEmpty(product.MaThuongHieu))
                    {
                        using (SqlCommand cm = new SqlCommand("SELECT TenThuongHieu FROM THUONGHIEU WHERE MaThuongHieu = @MaThuongHieu", cn))
                        {
                            cm.Parameters.AddWithValue("@MaThuongHieu", product.MaThuongHieu);
                            object result = cm.ExecuteScalar();
                            tenThuongHieu = result?.ToString() ?? "Không có dữ liệu!";
                        }
                    }

                    // Lấy tên danh mục
                    string tenDanhMuc = "Không có dữ liệu!";
                    if (product.MaDanhMuc.HasValue)
                    {
                        using (SqlCommand cm = new SqlCommand("SELECT TenDanhMuc FROM DANHMUC WHERE MaDanhMuc = @MaDanhMuc", cn))
                        {
                            cm.Parameters.AddWithValue("@MaDanhMuc", product.MaDanhMuc.Value);
                            object result = cm.ExecuteScalar();
                            tenDanhMuc = result?.ToString() ?? "Không có dữ liệu!";
                        }
                    }

                    // Lấy tên đơn vị tính
                    string tenDonViTinh = "Không có dữ liệu!";
                    if (product.MaDonViTinh.HasValue)
                    {
                        using (SqlCommand cm = new SqlCommand("SELECT TenDonViTinh FROM DONVITINH WHERE MaDonViTinh = @MaDonViTinh", cn))
                        {
                            cm.Parameters.AddWithValue("@MaDonViTinh", product.MaDonViTinh.Value);
                            object result = cm.ExecuteScalar();
                            tenDonViTinh = result?.ToString() ?? "Không có dữ liệu!";
                        }
                    }

                    // Hiển thị thông tin chi tiết
                    lblProductName.Text = product.TenSanPham;
                    lblProductCode.Text = $"Mã Sản Phẩm: {product.MaSanPham}";
                    lblBarcode.Text = $"Mã Vạch: {product.MaVach}";
                    lblBrand.Text = tenThuongHieu;
                    lblCategory.Text = tenDanhMuc;
                    lblUnit.Text = tenDonViTinh;
                    lblReorderLevel.Text = product.MucTaiDatHang.ToString();
                    lblSellingPrice.Text = product.GiaBan.ToString("N0") + " VNĐ";
                    lblCostPrice.Text = product.GiaVon.ToString("N0") + " VNĐ";
                    lblProfit.Text = product.GiaVon != 0 ? ((product.GiaBan - product.GiaVon) / product.GiaVon * 100).ToString("F2") + "%" : "N/A";
                    lblCurrentStock.Text = product.SoLuong.ToString();
                    lblStockValue.Text = (product.SoLuong * product.GiaBan).ToString("N0") + " VNĐ";
                    lblActivityStatus.Text = product.TrangThaiHoatDong ? "Đang Kinh Doanh" : "Ngừng Kinh Doanh";
                    UpdateProductStatus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi khi tải thông tin chi tiết sản phẩm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateProductStatus()
        {
            if (product.TrangThaiHoatDong)
            {
                if (product.SoLuong > product.MucTaiDatHang)
                {
                    lblStatusDisplay.Text = "Còn Hàng";
                    lblStatusDisplay.BackColor = Color.Green;
                    lblStatusDisplay.ForeColor = Color.White;
                }
                else if (product.SoLuong <= product.MucTaiDatHang)
                {
                    lblStatusDisplay.Text = "Sắp Hết Hàng";
                    lblStatusDisplay.BackColor = Color.Yellow;
                    lblStatusDisplay.ForeColor = Color.Black;
                }
                else
                {
                    lblStatusDisplay.Text = "Hết Hàng";
                    lblStatusDisplay.BackColor = Color.Red;
                    lblStatusDisplay.ForeColor = Color.White;
                }
            }
            else
            {
                lblStatusDisplay.Text = "Ngừng Hoạt Động";
                lblStatusDisplay.BackColor = Color.Gray;
                lblStatusDisplay.ForeColor = Color.White;
            }
        }

        private void btnCloseProductDetails_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEditProduct_Click(object sender, EventArgs e)
        {
            ProductModule editForm = new ProductModule(product);
            editForm.ProductAdded += (s, args) =>
            {
                ProductUpdated?.Invoke(this, EventArgs.Empty); // Thông báo cập nhật
                this.Close();
            };
            editForm.ShowDialog();
        }

        private void picCloseProductDetails_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
