﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConvenienceStore
{
    public partial class ProductModule : Form
    {

        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnect dbcon = new DBConnect();
        public event EventHandler ProductAdded;

        // Thêm thuộc tính để xác định chế độ
        public bool IsEditMode { get; set; }
        public Product.ProductData ProductToEdit { get; set; }

        // Danh sách ánh xạ giữa giá trị hiển thị và giá trị khóa
        private Dictionary<string, string> brandMapping = new Dictionary<string, string>(); // Ánh xạ TenThuongHieu -> MaThuongHieu
        private Dictionary<string, int> categoryMapping = new Dictionary<string, int>(); // Ánh xạ TenDanhMuc -> MaDanhMuc
        private Dictionary<string, string> originMapping = new Dictionary<string, string>(); // Ánh xạ TenQuocGia -> MaQuocGia
        public ProductModule()
        {
            InitializeComponent();

            // Đảm bảo không gán DataSource trong constructor
            cmbBrand.DataSource = null;
            cmbCategory.DataSource = null;
            cmbOrigin.DataSource = null;
            cmbUnitOfMeasure.DataSource = null;

            LoadComboBoxes();
            nudCurrentStock.ValueChanged += nudCurrentStock_ValueChanged;
            nudReorderLevel.ValueChanged += nudReorderLevel_ValueChanged;
            cmbStatus.SelectedIndexChanged += cmbStatus_SelectedIndexChanged;

            // Đặt giá trị mặc định cho cmbStatus
            if (cmbStatus.Items.Count > 0)
            {
                cmbStatus.SelectedIndex = 0; // Chọn "Đang Kinh Doanh"
            }

            UpdateProductStatus(); // Gọi lần đầu để thiết lập trạng thái ban đầu
        }

        // Constructor mới để hỗ trợ chế độ chỉnh sửa
        public ProductModule(Product.ProductData productToEdit) : this()
        {
            IsEditMode = true;
            ProductToEdit = productToEdit;

            // Đổi tiêu đề form
            lblTitle.Text = "Chỉnh sửa thông tin sản phẩm"; // Đảm bảo có lblTitle trên form
            btnAdd.Visible = false;
            btnSave.BringToFront();
            btnSave.Visible = true;

            // Điền dữ liệu vào các trường
            txtProductCode.Text = productToEdit.MaSanPham;
            txtBarcode.Text = productToEdit.MaVach;
            txtProductName.Text = productToEdit.TenSanPham;
            nudSellingPrice.Value = productToEdit.GiaBan;
            nudCostPrice.Value = productToEdit.GiaVon;
            nudCurrentStock.Value = productToEdit.SoLuong;
            nudReorderLevel.Value = productToEdit.MucTaiDatHang;
            cmbStatus.SelectedIndex = productToEdit.TrangThaiHoatDong ? 0 : 1;

            // Điền dữ liệu cho các ComboBox
            if (productToEdit.MaThuongHieu != null && brandMapping.ContainsValue(productToEdit.MaThuongHieu))
            {
                cmbBrand.SelectedItem = brandMapping.FirstOrDefault(x => x.Value == productToEdit.MaThuongHieu).Key;
            }
            if (productToEdit.MaDanhMuc.HasValue && categoryMapping.ContainsValue(productToEdit.MaDanhMuc.Value))
            {
                cmbCategory.SelectedItem = categoryMapping.FirstOrDefault(x => x.Value == productToEdit.MaDanhMuc.Value).Key;
            }
            if (productToEdit.MaQuocGia != null && originMapping.ContainsValue(productToEdit.MaQuocGia))
            {
                cmbOrigin.SelectedItem = originMapping.FirstOrDefault(x => x.Value == productToEdit.MaQuocGia).Key;
            }

            // Điền đơn vị tính
            if (productToEdit.MaDonViTinh.HasValue)
            {
                using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                {
                    cn.Open();
                    SqlCommand unitCmd = new SqlCommand("SELECT TenDonViTinh FROM DONVITINH WHERE MaDonViTinh = @MaDonViTinh", cn);
                    unitCmd.Parameters.AddWithValue("@MaDonViTinh", productToEdit.MaDonViTinh.Value);
                    var tenDonViTinh = unitCmd.ExecuteScalar()?.ToString();
                    if (tenDonViTinh != null)
                    {
                        cmbUnitOfMeasure.SelectedItem = tenDonViTinh;
                    }
                }
            }

            UpdateProductStatus();
        }

        private void LoadComboBoxes()
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                {
                    cn.Open();

                    // Load Thương Hiệu
                    SqlCommand brandCmd = new SqlCommand("SELECT MaThuongHieu, TenThuongHieu FROM THUONGHIEU", cn);
                    SqlDataReader brandReader = brandCmd.ExecuteReader();
                    brandMapping.Clear();
                    cmbBrand.Items.Clear();
                    while (brandReader.Read())
                    {
                        string tenThuongHieu = brandReader["TenThuongHieu"].ToString();
                        string maThuongHieu = brandReader.IsDBNull(brandReader.GetOrdinal("MaThuongHieu")) ? null : brandReader["MaThuongHieu"].ToString();
                        if (!string.IsNullOrEmpty(tenThuongHieu) && maThuongHieu != null)
                        {
                            brandMapping[tenThuongHieu] = maThuongHieu;
                            cmbBrand.Items.Add(tenThuongHieu);
                        }
                    }
                    brandReader.Close();
                    cmbBrand.SelectedIndex = -1; // Không chọn giá trị mặc định

                    // Load Danh Mục
                    SqlCommand categoryCmd = new SqlCommand("SELECT MaDanhMuc, TenDanhMuc FROM DANHMUC", cn);
                    SqlDataReader categoryReader = categoryCmd.ExecuteReader();
                    categoryMapping.Clear();
                    cmbCategory.Items.Clear();
                    while (categoryReader.Read())
                    {
                        string tenDanhMuc = categoryReader["TenDanhMuc"].ToString();
                        int maDanhMuc = categoryReader.IsDBNull(categoryReader.GetOrdinal("MaDanhMuc")) ? 0 : Convert.ToInt32(categoryReader["MaDanhMuc"]);
                        if (!string.IsNullOrEmpty(tenDanhMuc) && maDanhMuc != 0)
                        {
                            categoryMapping[tenDanhMuc] = maDanhMuc;
                            cmbCategory.Items.Add(tenDanhMuc);
                        }
                    }
                    categoryReader.Close();
                    cmbCategory.SelectedIndex = -1; // Không chọn giá trị mặc định

                    // Load Đơn Vị Tính
                    SqlCommand unitCmd = new SqlCommand("SELECT MaDonViTinh, TenDonViTinh FROM DONVITINH", cn);
                    SqlDataReader unitReader = unitCmd.ExecuteReader();
                    cmbUnitOfMeasure.Items.Clear();
                    Dictionary<string, int> unitMapping = new Dictionary<string, int>();
                    while (unitReader.Read())
                    {
                        string tenDonViTinh = unitReader["TenDonViTinh"].ToString();
                        int maDonViTinh = unitReader.IsDBNull(unitReader.GetOrdinal("MaDonViTinh")) ? 0 : Convert.ToInt32(unitReader["MaDonViTinh"]);
                        if (!string.IsNullOrEmpty(tenDonViTinh) && maDonViTinh != 0)
                        {
                            unitMapping[tenDonViTinh] = maDonViTinh;
                            cmbUnitOfMeasure.Items.Add(tenDonViTinh);
                        }
                    }
                    unitReader.Close();
                    cmbUnitOfMeasure.SelectedIndex = -1; // Không chọn giá trị mặc định

                    // Load Nguồn Gốc Xuất Xứ
                    SqlCommand originCmd = new SqlCommand("SELECT MaQuocGia, TenQuocGia FROM NGUONGOCCUATXU ORDER BY TenQuocGia", cn);
                    SqlDataReader originReader = originCmd.ExecuteReader();
                    originMapping.Clear();
                    cmbOrigin.Items.Clear();
                    while (originReader.Read())
                    {
                        string tenQuocGia = originReader["TenQuocGia"].ToString();
                        string maQuocGia = originReader.IsDBNull(originReader.GetOrdinal("MaQuocGia")) ? null : originReader["MaQuocGia"].ToString();
                        if (!string.IsNullOrEmpty(tenQuocGia) && maQuocGia != null)
                        {
                            originMapping[tenQuocGia] = maQuocGia;
                            cmbOrigin.Items.Add(tenQuocGia);
                        }
                    }
                    originReader.Close();
                    cmbOrigin.SelectedIndex = -1; // Không chọn giá trị mặc định
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private string GenerateProductCode()
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                {
                    cn.Open();

                    // Lấy số thứ tự mới từ BARCODE_SEQUENCE
                    SqlCommand getSeqCmd = new SqlCommand("SELECT TOP 1 SequenceNumber FROM BARCODE_SEQUENCE ORDER BY Id DESC", cn);
                    object result = getSeqCmd.ExecuteScalar();
                    if (result == null)
                    {
                        MessageBox.Show("Bảng BARCODE_SEQUENCE trống. Vui lòng khởi tạo dữ liệu.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return null;
                    }
                    int sequenceNumber = Convert.ToInt32(result);

                    // Tạo mã sản phẩm dạng "SP" + số thứ tự (5 chữ số)
                    string productCode = "SP" + sequenceNumber.ToString("D5"); // Ví dụ: SP00001
                    return productCode;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tạo mã sản phẩm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        private string GenerateEAN13Barcode()
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                {
                    cn.Open();

                    // Lấy số thứ tự mới từ BARCODE_SEQUENCE
                    SqlCommand getSeqCmd = new SqlCommand("SELECT TOP 1 SequenceNumber FROM BARCODE_SEQUENCE ORDER BY Id DESC", cn);
                    object result = getSeqCmd.ExecuteScalar();
                    if (result == null)
                    {
                        MessageBox.Show("Bảng BARCODE_SEQUENCE trống. Vui lòng khởi tạo dữ liệu.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return null;
                    }
                    int sequenceNumber = Convert.ToInt32(result);

                    // Lấy mã quốc gia từ cmbOrigin
                    string tenQuocGia = cmbOrigin.SelectedItem?.ToString();
                    string countryCode = tenQuocGia != null && originMapping.ContainsKey(tenQuocGia) ? originMapping[tenQuocGia] : "999"; // Mặc định là 999 nếu không chọn
                    string companyCode = "1234"; // Mã công ty cố định
                    string prefix = countryCode + companyCode; // Kết hợp mã quốc gia và mã công ty

                    // Tạo mã 12 chữ số
                    string sequenceStr = sequenceNumber.ToString("D5"); // Định dạng 5 chữ số (ví dụ: 00001)
                    string barcode12 = prefix + sequenceStr; // Ví dụ: 893123400001 (nếu chọn Việt Nam)

                    // Tính Check Digit
                    int sum = 0;
                    for (int i = 0; i < 12; i++)
                    {
                        int digit = int.Parse(barcode12[i].ToString());
                        sum += (i % 2 == 0) ? digit : digit * 3;
                    }
                    int checkDigit = (10 - (sum % 10)) % 10;

                    // Trả về mã EAN-13 (13 chữ số)
                    return barcode12 + checkDigit; // Ví dụ: 8931234000014
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tạo mã vạch: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }



        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                // Xác nhận lưu thông tin sản phẩm
                if (MessageBox.Show("Xác nhận lưu thông tin sản phẩm?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    // Tạo mã sản phẩm tự động
                    string productCode = GenerateProductCode();
                    if (productCode == null)
                    {
                        return;
                    }
                    txtProductCode.Text = productCode;

                    // Kiểm tra dữ liệu nhập vào
                    if (string.IsNullOrWhiteSpace(txtProductName.Text))
                    {
                        MessageBox.Show("Vui lòng nhập tên sản phẩm!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtProductName.Focus();
                        return;
                    }

                    if (nudSellingPrice.Value <= 0)
                    {
                        MessageBox.Show("Giá bán phải lớn hơn 0!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        nudSellingPrice.Focus();
                        return;
                    }

                    if (nudCostPrice.Value < 0)
                    {
                        MessageBox.Show("Giá vốn không được nhỏ hơn 0!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        nudCostPrice.Focus();
                        return;
                    }

                    // Tạo mã vạch tự động
                    string barcode = GenerateEAN13Barcode();
                    if (barcode == null)
                    {
                        return;
                    }
                    txtBarcode.Text = barcode;

                    using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                    {
                        cn.Open();

                        // Kiểm tra mã sản phẩm đã tồn tại chưa (dự phòng)
                        SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM SANPHAM WHERE MaSanPham = @MaSanPham", cn);
                        checkCmd.Parameters.AddWithValue("@MaSanPham", productCode);
                        int count = (int)checkCmd.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("Mã sản phẩm đã tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        // Lấy giá trị trạng thái hoạt động từ cmbStatus
                        bool trangThaiHoatDong = cmbStatus.SelectedIndex == 0; // 0: Đang Kinh Doanh, 1: Ngừng Kinh Doanh

                        // Lấy giá trị từ các ComboBox
                        string tenThuongHieu = cmbBrand.SelectedItem?.ToString();
                        string maThuongHieu = tenThuongHieu != null && brandMapping.ContainsKey(tenThuongHieu) ? brandMapping[tenThuongHieu] : null;

                        string tenDanhMuc = cmbCategory.SelectedItem?.ToString();
                        int? maDanhMuc = tenDanhMuc != null && categoryMapping.ContainsKey(tenDanhMuc) ? (int?)categoryMapping[tenDanhMuc] : null;

                        string tenQuocGia = cmbOrigin.SelectedItem?.ToString();
                        string maQuocGia = tenQuocGia != null && originMapping.ContainsKey(tenQuocGia) ? originMapping[tenQuocGia] : null;

                        // Lấy MaDonViTinh từ cmbUnitOfMeasure
                        string tenDonViTinh = cmbUnitOfMeasure.SelectedItem?.ToString();
                        int? maDonViTinh = null;
                        if (tenDonViTinh != null)
                        {
                            SqlCommand unitCmd = new SqlCommand("SELECT MaDonViTinh FROM DONVITINH WHERE TenDonViTinh = @TenDonViTinh", cn);
                            unitCmd.Parameters.AddWithValue("@TenDonViTinh", tenDonViTinh);
                            var result = unitCmd.ExecuteScalar();
                            maDonViTinh = result != null ? (int?)Convert.ToInt32(result) : null;
                        }

                        // Thêm sản phẩm mới
                        SqlCommand cmd = new SqlCommand(
                            "INSERT INTO SANPHAM (MaSanPham, MaVach, TenSanPham, MaThuongHieu, MaDanhMuc, GiaBan, SoLuong, MucTaiDatHang, MaDonViTinh, TrangThaiHoatDong, MaQuocGia, GiaVon) " +
                            "VALUES (@MaSanPham, @MaVach, @TenSanPham, @MaThuongHieu, @MaDanhMuc, @GiaBan, @SoLuong, @MucTaiDatHang, @MaDonViTinh, @TrangThaiHoatDong, @MaQuocGia, @GiaVon)", cn);

                        cmd.Parameters.AddWithValue("@MaSanPham", productCode);
                        cmd.Parameters.AddWithValue("@MaVach", barcode);
                        cmd.Parameters.AddWithValue("@TenSanPham", txtProductName.Text);
                        cmd.Parameters.AddWithValue("@MaThuongHieu", maThuongHieu != null ? (object)maThuongHieu : DBNull.Value);
                        cmd.Parameters.AddWithValue("@MaDanhMuc", maDanhMuc != null ? (object)maDanhMuc : DBNull.Value);
                        cmd.Parameters.AddWithValue("@GiaBan", nudSellingPrice.Value);
                        cmd.Parameters.AddWithValue("@SoLuong", (int)nudCurrentStock.Value);
                        cmd.Parameters.AddWithValue("@MucTaiDatHang", (int)nudReorderLevel.Value);
                        cmd.Parameters.AddWithValue("@MaDonViTinh", maDonViTinh != null ? (object)maDonViTinh : DBNull.Value);
                        cmd.Parameters.AddWithValue("@TrangThaiHoatDong", trangThaiHoatDong);
                        cmd.Parameters.AddWithValue("@MaQuocGia", maQuocGia != null ? (object)maQuocGia : DBNull.Value);
                        cmd.Parameters.AddWithValue("@GiaVon", nudCostPrice.Value);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            // Tăng SequenceNumber sau khi thêm thành công
                            SqlCommand updateSeqCmd = new SqlCommand("UPDATE BARCODE_SEQUENCE SET SequenceNumber = SequenceNumber + 1", cn);
                            updateSeqCmd.ExecuteNonQuery();

                            MessageBox.Show("Lưu thông tin sản phẩm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Xóa trắng các trường nhập liệu để chuẩn bị cho lần nhập tiếp theo
                            Clear();

                            // Kích hoạt sự kiện ProductAdded để thông báo cho form cha
                            ProductAdded?.Invoke(this, EventArgs.Empty);
                        }
                        else
                        {
                            MessageBox.Show("Không có dữ liệu nào được lưu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Clear()
        {
            txtProductCode.Clear();
            txtBarcode.Clear();
            txtProductName.Clear();
            if (cmbBrand.Items.Count > 0) cmbBrand.SelectedIndex = 0;
            if (cmbCategory.Items.Count > 0) cmbCategory.SelectedIndex = 0;
            nudSellingPrice.Value = 0;
            nudCostPrice.Value = 0;
            nudCurrentStock.Value = 0;
            nudReorderLevel.Value = 10; // Giá trị mặc định
            if (cmbUnitOfMeasure.Items.Count > 0) cmbUnitOfMeasure.SelectedIndex = 0;
            if (cmbStatus.Items.Count > 0) cmbStatus.SelectedIndex = 0; // Chọn "Đang Kinh Doanh"
            if (cmbOrigin.Items.Count > 0) cmbOrigin.SelectedIndex = 0;
            UpdateProductStatus(); // Cập nhật lại trạng thái sản phẩm
            txtProductName.Focus();
        }
        private void btnCancelProduct_Click(object sender, EventArgs e)
        {
            Clear();
        }
        private void UpdateProductStatus()
        {
            decimal currentStock = nudCurrentStock.Value;
            decimal reorderLevel = nudReorderLevel.Value;

            // Lấy giá trị trạng thái hoạt động từ cmbStatus
            bool trangThaiHoatDong = cmbStatus.SelectedIndex == 0; // 0: Đang Kinh Doanh, 1: Ngừng Kinh Doanh

            if (trangThaiHoatDong)
            {
                if (currentStock > reorderLevel)
                {
                    lblStatusDisplay.Text = "Còn Hàng";
                    lblStatusDisplay.BackColor = Color.Green;
                    lblStatusDisplay.ForeColor = Color.White;
                }
                else if (currentStock <= reorderLevel)
                {
                    lblStatusDisplay.Text = "Sắp Hết Hàng";
                    lblStatusDisplay.BackColor = Color.Yellow;
                    lblStatusDisplay.ForeColor = Color.Black;
                }
                else
                {
                    lblStatusDisplay.Text = "Hết Hàng";
                    lblStatusDisplay.BackColor = Color.Red;
                    lblStatusDisplay.ForeColor = Color.White;
                }
            }
            else
            {
                lblStatusDisplay.Text = "Ngừng Kinh Doanh";
                lblStatusDisplay.BackColor = Color.Gray;
                lblStatusDisplay.ForeColor = Color.White;
            }
        }

        private void nudCurrentStock_ValueChanged(object sender, EventArgs e)
        {
            UpdateProductStatus();
        }

        private void nudReorderLevel_ValueChanged(object sender, EventArgs e)
        {
            UpdateProductStatus();
        }
        private void btnCloseProduct_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
        private void picClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void txtBarcode_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNameProduct_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtProductCode_TextChanged(object sender, EventArgs e)
        {

        }



        private void cmbBrand_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        private void tabBasicInfo_Click(object sender, EventArgs e)
        {

        }


        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbUnitOfMeasure_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        private void tabPricingStock_Click(object sender, EventArgs e)
        {

        }




        private void tabProduct_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void label6_Click(object sender, EventArgs e)
        {

        }
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void label7_Click(object sender, EventArgs e)
        {

        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        { }

        private void cmbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateProductStatus();
        }

        private void ProductModule_Load(object sender, EventArgs e)
        {

        }

        private void picCloseProductModule_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Xác nhận lưu thông tin sản phẩm?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (string.IsNullOrWhiteSpace(txtProductName.Text))
                    {
                        MessageBox.Show("Vui lòng nhập tên sản phẩm!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtProductName.Focus();
                        return;
                    }

                    if (nudSellingPrice.Value <= 0)
                    {
                        MessageBox.Show("Giá bán phải lớn hơn 0!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        nudSellingPrice.Focus();
                        return;
                    }

                    if (nudCostPrice.Value < 0)
                    {
                        MessageBox.Show("Giá vốn không được nhỏ hơn 0!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        nudCostPrice.Focus();
                        return;
                    }

                    using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                    {
                        cn.Open();

                        // Lấy giá trị trạng thái hoạt động từ cmbStatus
                        bool trangThaiHoatDong = cmbStatus.SelectedIndex == 0;

                        // Lấy giá trị từ các ComboBox
                        string tenThuongHieu = cmbBrand.SelectedItem?.ToString();
                        string maThuongHieu = tenThuongHieu != null && brandMapping.ContainsKey(tenThuongHieu) ? brandMapping[tenThuongHieu] : null;

                        string tenDanhMuc = cmbCategory.SelectedItem?.ToString();
                        int? maDanhMuc = tenDanhMuc != null && categoryMapping.ContainsKey(tenDanhMuc) ? (int?)categoryMapping[tenDanhMuc] : null;

                        string tenQuocGia = cmbOrigin.SelectedItem?.ToString();
                        string maQuocGia = tenQuocGia != null && originMapping.ContainsKey(tenQuocGia) ? originMapping[tenQuocGia] : null;

                        string tenDonViTinh = cmbUnitOfMeasure.SelectedItem?.ToString();
                        int? maDonViTinh = null;
                        if (tenDonViTinh != null)
                        {
                            SqlCommand unitCmd = new SqlCommand("SELECT MaDonViTinh FROM DONVITINH WHERE TenDonViTinh = @TenDonViTinh", cn);
                            unitCmd.Parameters.AddWithValue("@TenDonViTinh", tenDonViTinh);
                            var result = unitCmd.ExecuteScalar();
                            maDonViTinh = result != null ? (int?)Convert.ToInt32(result) : null;
                        }

                        // Cập nhật sản phẩm
                        SqlCommand cmd = new SqlCommand(
                            "UPDATE SANPHAM SET MaVach = @MaVach, TenSanPham = @TenSanPham, MaThuongHieu = @MaThuongHieu, MaDanhMuc = @MaDanhMuc, GiaBan = @GiaBan, SoLuong = @SoLuong, MucTaiDatHang = @MucTaiDatHang, MaDonViTinh = @MaDonViTinh, TrangThaiHoatDong = @TrangThaiHoatDong, MaQuocGia = @MaQuocGia, GiaVon = @GiaVon " +
                            "WHERE MaSanPham = @MaSanPham", cn);

                        cmd.Parameters.AddWithValue("@MaSanPham", txtProductCode.Text);
                        cmd.Parameters.AddWithValue("@MaVach", txtBarcode.Text);
                        cmd.Parameters.AddWithValue("@TenSanPham", txtProductName.Text);
                        cmd.Parameters.AddWithValue("@MaThuongHieu", maThuongHieu != null ? (object)maThuongHieu : DBNull.Value);
                        cmd.Parameters.AddWithValue("@MaDanhMuc", maDanhMuc != null ? (object)maDanhMuc : DBNull.Value);
                        cmd.Parameters.AddWithValue("@GiaBan", nudSellingPrice.Value);
                        cmd.Parameters.AddWithValue("@SoLuong", (int)nudCurrentStock.Value);
                        cmd.Parameters.AddWithValue("@MucTaiDatHang", (int)nudReorderLevel.Value);
                        cmd.Parameters.AddWithValue("@MaDonViTinh", maDonViTinh != null ? (object)maDonViTinh : DBNull.Value);
                        cmd.Parameters.AddWithValue("@TrangThaiHoatDong", trangThaiHoatDong);
                        cmd.Parameters.AddWithValue("@MaQuocGia", maQuocGia != null ? (object)maQuocGia : DBNull.Value);
                        cmd.Parameters.AddWithValue("@GiaVon", nudCostPrice.Value);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Cập nhật thông tin sản phẩm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ProductAdded?.Invoke(this, EventArgs.Empty);
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Không có dữ liệu nào được cập nhật!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
