﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace ConvenienceStore
{
    public partial class UpdateBrand : Form
    {
        

        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnect dbcon = new DBConnect();

        public event EventHandler BrandSaved;

        private string maThuongHieuCu;

        public UpdateBrand(string maCu, string tenThuongHieu)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.myConnection());

            maThuongHieuCu = maCu; // Gán mã thương hiệu cũ
            txtBrandCodeUp.Text = maCu; // Hiển thị mã cũ để sửa
            txtBrandNameUp.Text = tenThuongHieu;

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Bạn có chắc chắn muốn cập nhật thông tin không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string maThuongHieuMoi = txtBrandCodeUp.Text.Trim();
                    string tenThuongHieu = txtBrandNameUp.Text.Trim();

                    if (string.IsNullOrWhiteSpace(maThuongHieuMoi) || string.IsNullOrWhiteSpace(tenThuongHieu))
                    {
                        MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (maThuongHieuMoi.Length > 10)
                    {
                        MessageBox.Show("Mã thương hiệu không được quá 10 ký tự!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (tenThuongHieu.Length > 50)
                    {
                        MessageBox.Show("Tên thương hiệu không được quá 50 ký tự!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                    {
                        cn.Open();

                        // Kiểm tra xem mã mới đã tồn tại chưa
                        using (SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM THUONGHIEU WHERE MaThuongHieu = @MaMoi", cn))
                        {
                            checkCmd.Parameters.AddWithValue("@MaMoi", maThuongHieuMoi);
                            int count = (int)checkCmd.ExecuteScalar();
                            if (count > 0 && maThuongHieuMoi != maThuongHieuCu)
                            {
                                MessageBox.Show("Mã thương hiệu mới đã tồn tại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }

                        // Cập nhật dữ liệu
                        using (SqlCommand cm = new SqlCommand("UPDATE THUONGHIEU SET MaThuongHieu = @MaMoi, TenThuongHieu = @TenMoi WHERE MaThuongHieu = @MaCu", cn))
                        {
                            cm.Parameters.AddWithValue("@MaCu", maThuongHieuCu);
                            cm.Parameters.AddWithValue("@MaMoi", maThuongHieuMoi);
                            cm.Parameters.AddWithValue("@TenMoi", tenThuongHieu);

                            int rowsAffected = cm.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Cập nhật thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                BrandSaved?.Invoke(this, EventArgs.Empty);
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Không có dữ liệu nào được cập nhật!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
   
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
