﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConvenienceStore
{
    public partial class UpdateCategory : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnect dbcon = new DBConnect();

        public event EventHandler CategorySaved;
        private string maDanhMuc;
        public UpdateCategory(string maDanhMuc, string tenDanhMuc)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.myConnection());

            this.maDanhMuc = maDanhMuc; // Lưu mã danh mục để cập nhật
            txtCategoryNameUp.Text = tenDanhMuc; // Hiển thị tên danh mục để sửa
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Bạn có chắc chắn muốn cập nhật thông tin danh mục không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string tenDanhMuc = txtCategoryNameUp.Text.Trim();

                    if (string.IsNullOrWhiteSpace(tenDanhMuc))
                    {
                        MessageBox.Show("Vui lòng nhập tên danh mục!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (tenDanhMuc.Length > 50)
                    {
                        MessageBox.Show("Tên danh mục không được quá 50 ký tự!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    using (SqlConnection cn = new SqlConnection(dbcon.myConnection()))
                    {
                        cn.Open();

                        // Kiểm tra xem TenDanhMuc đã tồn tại chưa (trừ bản ghi hiện tại)
                        using (SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM DANHMUC WHERE TenDanhMuc = @TenDanhMuc AND MaDanhMuc != @MaDanhMuc", cn))
                        {
                            checkCmd.Parameters.AddWithValue("@TenDanhMuc", tenDanhMuc);
                            checkCmd.Parameters.AddWithValue("@MaDanhMuc", maDanhMuc);
                            int count = (int)checkCmd.ExecuteScalar();
                            if (count > 0)
                            {
                                MessageBox.Show("Tên danh mục đã tồn tại! Vui lòng chọn tên khác.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }

                        // Cập nhật dữ liệu
                        using (SqlCommand cm = new SqlCommand("UPDATE DANHMUC SET TenDanhMuc = @TenDanhMuc WHERE MaDanhMuc = @MaDanhMuc", cn))
                        {
                            cm.Parameters.AddWithValue("@MaDanhMuc", maDanhMuc);
                            cm.Parameters.AddWithValue("@TenDanhMuc", tenDanhMuc);

                            int rowsAffected = cm.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Cập nhật danh mục thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                CategorySaved?.Invoke(this, EventArgs.Empty);
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Không có dữ liệu nào được cập nhật!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
