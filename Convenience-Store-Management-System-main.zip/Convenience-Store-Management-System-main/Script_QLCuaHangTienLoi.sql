﻿-- TẠO CƠ SỞ DỮ LIỆU QLCuaHangTienLoi
USE master 
GO 

CREATE DATABASE QLCuaHangTienLoi 
GO 

-- Thiết lập các thuộc tính cho cơ sở dữ liệu
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled')) -- Kiểm tra xem dịch vụ Full-Text Search có được cài đặt hay không
begin 
EXEC QLCuaHangTienLoi.dbo.sp_fulltext_database @action = 'enable' -- Kích hoạt Full-Text Search cho cơ sở dữ liệu QLCuaHangTienLoi
end 
GO 

ALTER DATABASE QLCuaHangTienLoi SET ANSI_NULL_DEFAULT OFF -- Tắt thiết lập ANSI: Khi không chỉ định giá trị cho cột, không tự động gán NULL
GO 

ALTER DATABASE QLCuaHangTienLoi SET ANSI_NULLS OFF -- Tắt thiết lập ANSI: So sánh với NULL sẽ không tuân theo chuẩn ANSI (NULL = NULL trả về false)
GO 

ALTER DATABASE QLCuaHangTienLoi SET ANSI_PADDING OFF -- Tắt thiết lập ANSI: Không tự động thêm ký tự đệm (padding) cho kiểu dữ liệu char/varchar
GO 

ALTER DATABASE QLCuaHangTienLoi SET ANSI_WARNINGS OFF -- Tắt cảnh báo ANSI: Không hiển thị cảnh báo khi có lỗi như chia cho 0 hoặc dữ liệu bị cắt bớt
GO 

ALTER DATABASE QLCuaHangTienLoi SET ARITHABORT OFF -- Tắt thiết lập: Không hủy bỏ truy vấn khi có lỗi số học (như chia cho 0)
GO 

ALTER DATABASE QLCuaHangTienLoi SET AUTO_CLOSE ON -- Bật thiết lập: Tự động đóng cơ sở dữ liệu khi không có kết nối nào sử dụng
GO 

ALTER DATABASE QLCuaHangTienLoi SET AUTO_SHRINK ON -- Bật thiết lập: Tự động thu nhỏ kích thước cơ sở dữ liệu khi có không gian trống
GO 

ALTER DATABASE QLCuaHangTienLoi SET AUTO_UPDATE_STATISTICS ON -- Bật thiết lập: Tự động cập nhật thống kê để tối ưu hóa truy vấn
GO 

ALTER DATABASE QLCuaHangTienLoi SET CURSOR_CLOSE_ON_COMMIT OFF -- Tắt thiết lập: Không tự động đóng con trỏ (cursor) sau khi commit giao dịch
GO 

ALTER DATABASE QLCuaHangTienLoi SET CURSOR_DEFAULT  GLOBAL -- Thiết lập: Con trỏ (cursor) có phạm vi toàn cục (có thể truy cập từ bất kỳ đâu trong phiên làm việc)
GO 

ALTER DATABASE QLCuaHangTienLoi SET CONCAT_NULL_YIELDS_NULL OFF -- Tắt thiết lập: Khi nối chuỗi với NULL, kết quả không trả về NULL mà là chuỗi rỗng
GO 

ALTER DATABASE QLCuaHangTienLoi SET NUMERIC_ROUNDABORT OFF -- Tắt thiết lập: Không hủy bỏ truy vấn khi có lỗi làm tròn số (numeric overflow/underflow)
GO 

ALTER DATABASE QLCuaHangTienLoi SET QUOTED_IDENTIFIER OFF -- Tắt thiết lập: Không sử dụng dấu nháy kép ("") để định danh, chỉ dùng dấu nháy đơn ('') cho chuỗi
GO 

ALTER DATABASE QLCuaHangTienLoi SET RECURSIVE_TRIGGERS OFF -- Tắt thiết lập: Không cho phép trigger gọi đệ quy (trigger gọi lại chính nó)
GO 

ALTER DATABASE QLCuaHangTienLoi SET  ENABLE_BROKER -- Bật Service Broker, cho phép cơ sở dữ liệu sử dụng tính năng nhắn tin và hàng đợi
GO 

ALTER DATABASE QLCuaHangTienLoi SET AUTO_UPDATE_STATISTICS_ASYNC OFF -- Tắt thiết lập: Không cập nhật thống kê một cách bất đồng bộ (asynchronous)
GO 

ALTER DATABASE QLCuaHangTienLoi SET DATE_CORRELATION_OPTIMIZATION OFF -- Tắt thiết lập: Không tối ưu hóa truy vấn dựa trên mối quan hệ giữa các cột ngày
GO 

ALTER DATABASE QLCuaHangTienLoi SET TRUSTWORTHY OFF -- Tắt thiết lập: Không cho phép cơ sở dữ liệu được đánh dấu là đáng tin cậy (liên quan đến bảo mật)
GO 

ALTER DATABASE QLCuaHangTienLoi SET ALLOW_SNAPSHOT_ISOLATION OFF -- Tắt thiết lập: Không cho phép cơ chế cách ly giao dịch Snapshot Isolation
GO 

ALTER DATABASE QLCuaHangTienLoi SET PARAMETERIZATION SIMPLE -- Thiết lập: Sử dụng tham số hóa đơn giản cho truy vấn (không ép buộc tham số hóa)
GO 

ALTER DATABASE QLCuaHangTienLoi SET READ_COMMITTED_SNAPSHOT OFF -- Tắt thiết lập: Không sử dụng cơ chế Read Committed Snapshot Isolation
GO 

ALTER DATABASE QLCuaHangTienLoi SET HONOR_BROKER_PRIORITY OFF -- Tắt thiết lập: Không ưu tiên xử lý thông điệp Service Broker theo mức độ ưu tiên
GO 

ALTER DATABASE QLCuaHangTienLoi SET RECOVERY SIMPLE -- Thiết lập: Sử dụng mô hình khôi phục đơn giản (Simple Recovery Model), không lưu trữ toàn bộ nhật ký giao dịch
GO 

ALTER DATABASE QLCuaHangTienLoi SET  MULTI_USER -- Thiết lập: Cho phép nhiều người dùng truy cập cơ sở dữ liệu cùng lúc
GO 

ALTER DATABASE QLCuaHangTienLoi SET PAGE_VERIFY CHECKSUM -- Thiết lập: Sử dụng kiểm tra checksum để phát hiện lỗi hỏng trang dữ liệu
GO 

ALTER DATABASE QLCuaHangTienLoi SET DB_CHAINING OFF -- Tắt thiết lập: Không cho phép liên kết quyền sở hữu chéo giữa các cơ sở dữ liệu
GO 

ALTER DATABASE QLCuaHangTienLoi SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) -- Tắt thiết lập: Không cho phép truy cập FileStream không giao dịch
GO 

ALTER DATABASE QLCuaHangTienLoi SET TARGET_RECOVERY_TIME = 60 SECONDS -- Thiết lập: Đặt thời gian mục tiêu để khôi phục cơ sở dữ liệu là 60 giây
GO 

ALTER DATABASE QLCuaHangTienLoi SET DELAYED_DURABILITY = DISABLED -- Tắt thiết lập: Không sử dụng độ bền giao dịch trễ (delayed durability)
GO 

ALTER DATABASE QLCuaHangTienLoi SET ACCELERATED_DATABASE_RECOVERY = OFF -- Tắt thiết lập: Không sử dụng khôi phục cơ sở dữ liệu nhanh (Accelerated Database Recovery)
GO 

ALTER DATABASE QLCuaHangTienLoi SET QUERY_STORE = OFF -- Tắt thiết lập: Không sử dụng Query Store để theo dõi và tối ưu hóa truy vấn
GO 

ALTER DATABASE QLCuaHangTienLoi SET  READ_WRITE -- Thiết lập: Cho phép cơ sở dữ liệu ở chế độ đọc và ghi (không phải chỉ đọc)
GO 

USE QLCuaHangTienLoi 
GO 

-- 1. BẢNG NGUOIDUNG
CREATE TABLE dbo.NGUOIDUNG (
    TenDangNhap nvarchar(50) NOT NULL,
    MatKhau nvarchar(50) NOT NULL,
    VaiTro nvarchar(20) NULL,
    HoTen nvarchar(100) NULL,
    TrangThaiHoatDong bit NULL,
    CONSTRAINT PK_NGUOIDUNG PRIMARY KEY CLUSTERED (TenDangNhap ASC)
)

/*-- Thêm dữ liệu mẫu cho bảng NGUOIDUNG
INSERT INTO NGUOIDUNG (TenDangNhap, MatKhau, VaiTro, HoTen, TrangThaiHoatDong)
VALUES ('admin', 'admin123', 'Admin', 'Nguyễn Văn A', 1),
       ('employee1', '123456', 'Employee', 'Trần Thị B', 1),
       ('employee2', '123456', 'Employee', 'Lê Văn C', 0)
GO */

-- 2. BẢNG DANHMUC 
CREATE TABLE dbo.DANHMUC (
    MaDanhMuc int IDENTITY(1,1) NOT NULL,
    TenDanhMuc nvarchar(50) NULL,
    CONSTRAINT PK_DANHMUC PRIMARY KEY CLUSTERED (MaDanhMuc ASC)
)

-- Thêm dữ liệu mẫu cho bảng DANHMUC
INSERT INTO DANHMUC (TenDanhMuc)
VALUES (N'Bánh kẹo'), (N'Sữa'), (N'Đồ dùng cá nhân')
GO

-- 3. BẢNG THUONGHIEU 
CREATE TABLE dbo.THUONGHIEU (
    MaThuongHieu nvarchar(10) NOT NULL, 
    TenThuongHieu nvarchar(50) NULL,
    CONSTRAINT PK_THUONGHIEU PRIMARY KEY CLUSTERED (MaThuongHieu ASC)
) 

-- Thêm dữ liệu mẫu cho bảng THUONGHIEU với mã ký hiệu
INSERT INTO THUONGHIEU (MaThuongHieu, TenThuongHieu)
VALUES ('NTF', 'Nutifood'), 
	('VNM', 'Vinamilk'),
	('KDC', N'Kinh Đô'), 
	('MHV', N'Mỹ Hảo'), 
	('VSC', 'Vissan'),
	('ACV', N'Acecook Việt Nam'),
	('CSU', 'Chinsu'),
	('THK', 'Thorakao'),
	('DIU', 'Diana Unicharm')
GO

-- 4. BẢNG NHACUNGCAP (Mã nhà cung cấp tự cấu hình)
CREATE TABLE dbo.NHACUNGCAP (
    MaNhaCungCap int IDENTITY(1,1) NOT NULL,
    TenNhaCungCap nvarchar(100) NULL,
    DiaChi nvarchar(200) NULL,
    NguoiLienHe nvarchar(100) NULL,
    SoDienThoai nvarchar(20) NULL,
    Email nvarchar(100) NULL,
    CONSTRAINT PK_NHACUNGCAP PRIMARY KEY CLUSTERED (MaNhaCungCap ASC)
) 

-- Thêm dữ liệu mẫu cho bảng NHACUNGCAP với mã tự cấu hình
INSERT INTO NHACUNGCAP ( TenNhaCungCap, DiaChi, NguoiLienHe, SoDienThoai, Email)
VALUES ( N'CTCP Mondelez Kinh Đô Việt Nam', N'116/46 Bình Lợi, Phường 13, Quận Bình Thạnh, TP.HCM', N'Nguyễn Văn Danh', '0919838786', 'banhkinhdo.net@gmail.com'),
       (N'CTCP Sữa Việt Nam', N'Số 10, Đường Tân Trào, Phường Tân Phú, Quận 7, Tp. HCM', N'Trần Ngọc Ngân', '0918234567', 'vinamilk@vinamilk.com.vn'),
	   (N'CTCP Diana Unicharm', N'Khu công nghiệp Vĩnh Tuy, Lĩnh Nam, Hoàng Mai, Hà Nội', N'Huỳnh Tấn Phước', '0936445758', 'diana.care@unicharm.com')
GO

-- 5. BẢNG DONVITINH
CREATE TABLE dbo.DONVITINH (
    MaDonViTinh int IDENTITY(1,1) NOT NULL,
    TenDonViTinh nvarchar(20) NULL,
    CONSTRAINT PK_DONVITINH PRIMARY KEY CLUSTERED (MaDonViTinh ASC)
) 

-- Thêm dữ liệu mẫu cho bảng DONVITINH
INSERT INTO DONVITINH (TenDonViTinh)
VALUES (N'chai'), (N'thùng'), (N'hộp'), (N'cái'), (N'ly'), (N'gói'), (N'lốc'), (N'lon')
GO

-- 6. BẢNG SANPHAM
CREATE TABLE dbo.SANPHAM (
    MaSanPham nvarchar(50) NOT NULL,
    MaVach nvarchar(50) NULL,
    MoTaSanPham nvarchar(200) NULL,
    MaThuongHieu nvarchar(10) NULL, 
    MaDanhMuc int NULL,
    Gia decimal(18,2) NULL,
    SoLuong int NULL,
    MucTaiDatHang int NULL,
    BaseUnitID int NULL,
    CONSTRAINT PK_SANPHAM PRIMARY KEY CLUSTERED (MaSanPham ASC),
    CONSTRAINT FK_SANPHAM_THUONGHIEU FOREIGN KEY(MaThuongHieu) REFERENCES THUONGHIEU(MaThuongHieu),
    CONSTRAINT FK_SANPHAM_DANHMUC FOREIGN KEY(MaDanhMuc) REFERENCES DANHMUC(MaDanhMuc),
    CONSTRAINT FK_SANPHAM_DONVITINH FOREIGN KEY(BaseUnitID) REFERENCES DONVITINH(MaDonViTinh)
) 

-- 7. BẢNG QUY ĐỔI ĐƠN VỊ
CREATE TABLE dbo.QUYDOIDONVI(
    MaSanPham nvarchar(50) NOT NULL,
    MaDonViTinh int NOT NULL,
    SoLuongCoBan decimal(18,2) NOT NULL,
    CONSTRAINT PK_SANPHAM_DONVITINH PRIMARY KEY CLUSTERED (MaSanPham, MaDonViTinh),
    CONSTRAINT FK_SPDV_SANPHAM FOREIGN KEY(MaSanPham) REFERENCES SANPHAM(MaSanPham),
    CONSTRAINT FK_SPDV_DONVITINH FOREIGN KEY(MaDonViTinh) REFERENCES DONVITINH(MaDonViTinh)
) 


-- 8. BẢNG NHAPKHO
CREATE TABLE dbo.NHAPKHO (
    MaNhapKho int IDENTITY(1,1) NOT NULL,
    SoThamChieu nvarchar(50) NULL,
    MaSanPham nvarchar(50) NULL,
    SoLuong int NULL,
    NgayNhap datetime NULL,
    NguoiNhap nvarchar(50) NULL,
    TrangThai nvarchar(20) NULL,
    MaNhaCungCap int NOT NULL,
    MaDonViTinhNhapKho int NULL,
    CONSTRAINT PK_NHAPKHO PRIMARY KEY CLUSTERED (MaNhapKho ASC),
    CONSTRAINT FK_NHAPKHO_SANPHAM FOREIGN KEY(MaSanPham) REFERENCES SANPHAM(MaSanPham),
    CONSTRAINT FK_NHAPKHO_NGUOIDUNG FOREIGN KEY(NguoiNhap) REFERENCES NGUOIDUNG(TenDangNhap),
    CONSTRAINT FK_NHAPKHO_NHACUNGCAP FOREIGN KEY(MaNhaCungCap) REFERENCES NHACUNGCAP(MaNhaCungCap),
    CONSTRAINT FK_NHAPKHO_DONVITINH FOREIGN KEY(MaDonViTinhNhapKho) REFERENCES DONVITINH(MaDonViTinh)
) 

-- 9. BẢNG GIOHANG
CREATE TABLE dbo.GIOHANG (
    MaGioHang int IDENTITY(1,1) NOT NULL,
    SoGiaoDich nvarchar(50) NULL,
    MaSanPham nvarchar(50) NULL,
    Gia decimal(18,2) NULL,
    SoLuong int NULL,
    TyLeGiamGia decimal(5,2) NULL,
    SoTienGiamGia decimal(18,2) NULL,
    TongTien decimal(18,2) NULL,
    NgayTao datetime NULL,
    TrangThai nvarchar(20) NULL,
    ThuNgan nvarchar(50) NULL,
    CONSTRAINT PK_GIOHANG PRIMARY KEY CLUSTERED (MaGioHang ASC),
    CONSTRAINT FK_GIOHANG_SANPHAM FOREIGN KEY(MaSanPham) REFERENCES SANPHAM(MaSanPham),
    CONSTRAINT FK_GIOHANG_NGUOIDUNG FOREIGN KEY(ThuNgan) REFERENCES NGUOIDUNG(TenDangNhap)
) 

-- 10. BẢNG DIEUCHINH
CREATE TABLE dbo.DIEUCHINH (
    MaDieuChinh int IDENTITY(1,1) NOT NULL,
    SoGiaoDich nvarchar(50) NULL,
    MaSanPham nvarchar(50) NULL,
    SoLuong int NULL,
    HanhDong nvarchar(50) NULL,
    GhiChu nvarchar(200) NULL,
    NgayDieuChinh datetime NULL,
    NguoiThucHien nvarchar(50) NULL,
    CONSTRAINT PK_DIEUCHINH PRIMARY KEY CLUSTERED (MaDieuChinh ASC),
    CONSTRAINT FK_DIEUCHINH_SANPHAM FOREIGN KEY(MaSanPham) REFERENCES SANPHAM(MaSanPham),
    CONSTRAINT FK_DIEUCHINH_NGUOIDUNG FOREIGN KEY(NguoiThucHien) REFERENCES NGUOIDUNG(TenDangNhap)
) 


-- Trigger để tự động cập nhật số lượng tồn kho khi nhập kho
CREATE TRIGGER trg_NHAPKHO_UpdateInventory
ON NHAPKHO
AFTER INSERT
AS
BEGIN
    UPDATE s
    SET s.SoLuong = s.SoLuong + (i.SoLuong * d.SoLuongCoBan)
    FROM SANPHAM s
    JOIN inserted i ON s.MaSanPham = i.MaSanPham
    JOIN QUYDOIDONVI d ON s.MaSanPham = d.MaSanPham AND i.MaDonViTinhNhapKho = d.MaDonViTinh
END
GO


